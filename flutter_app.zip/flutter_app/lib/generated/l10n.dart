// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

class S {
  S();
  
  static const AppLocalizationDelegate delegate =
    AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false) ? locale.languageCode : locale.toString();
    final localeName = Intl.canonicalizedLocale(name); 
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      return S();
    });
  } 

  static S of(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  String get search_for_markets_or_products {
    return Intl.message(
      'Search for markets or products',
      name: 'search_for_markets_or_products',
      desc: '',
      args: [],
    );
  }

  String get top_markets {
    return Intl.message(
      'Top Markets',
      name: 'top_markets',
      desc: '',
      args: [],
    );
  }

  String get ordered_by_nearby_first {
    return Intl.message(
      'Ordered by Nearby first',
      name: 'ordered_by_nearby_first',
      desc: '',
      args: [],
    );
  }

  String get trending_this_week {
    return Intl.message(
      'Trending This Week',
      name: 'trending_this_week',
      desc: '',
      args: [],
    );
  }

  String get double_click_on_the_product_to_add_it_to_the {
    return Intl.message(
      'Double click on the product to add it to the cart',
      name: 'double_click_on_the_product_to_add_it_to_the',
      desc: '',
      args: [],
    );
  }

  String get product_categories {
    return Intl.message(
      'Product Categories',
      name: 'product_categories',
      desc: '',
      args: [],
    );
  }

  String get most_popular {
    return Intl.message(
      'Most Popular',
      name: 'most_popular',
      desc: '',
      args: [],
    );
  }

  String get recent_reviews {
    return Intl.message(
      'Recent Reviews',
      name: 'recent_reviews',
      desc: '',
      args: [],
    );
  }

  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  String get skip {
    return Intl.message(
      'Skip',
      name: 'skip',
      desc: '',
      args: [],
    );
  }

  String get about {
    return Intl.message(
      'About',
      name: 'about',
      desc: '',
      args: [],
    );
  }

  String get submit {
    return Intl.message(
      'Submit',
      name: 'submit',
      desc: '',
      args: [],
    );
  }

  String get verify {
    return Intl.message(
      'Verify',
      name: 'verify',
      desc: '',
      args: [],
    );
  }

  String get select_your_preferred_languages {
    return Intl.message(
      'Select your preferred languages',
      name: 'select_your_preferred_languages',
      desc: '',
      args: [],
    );
  }

  String get order_id {
    return Intl.message(
      'Order Id',
      name: 'order_id',
      desc: '',
      args: [],
    );
  }

  String get category {
    return Intl.message(
      'Category',
      name: 'category',
      desc: '',
      args: [],
    );
  }

  String get checkout {
    return Intl.message(
      'Checkout',
      name: 'checkout',
      desc: '',
      args: [],
    );
  }

  String get payment_mode {
    return Intl.message(
      'Payment Mode',
      name: 'payment_mode',
      desc: '',
      args: [],
    );
  }

  String get select_your_preferred_payment_mode {
    return Intl.message(
      'Select your preferred payment mode',
      name: 'select_your_preferred_payment_mode',
      desc: '',
      args: [],
    );
  }

  String get or_checkout_with {
    return Intl.message(
      'Or Checkout With',
      name: 'or_checkout_with',
      desc: '',
      args: [],
    );
  }

  String get subtotal {
    return Intl.message(
      'Subtotal',
      name: 'subtotal',
      desc: '',
      args: [],
    );
  }

  String get total {
    return Intl.message(
      'Total',
      name: 'total',
      desc: '',
      args: [],
    );
  }

  String get confirm_payment {
    return Intl.message(
      'Confirm Payment',
      name: 'confirm_payment',
      desc: '',
      args: [],
    );
  }

  String get menu {
    return Intl.message(
      'Menu',
      name: 'menu',
      desc: '',
      args: [],
    );
  }

  String get information {
    return Intl.message(
      'Information',
      name: 'information',
      desc: '',
      args: [],
    );
  }

  String get featured_products {
    return Intl.message(
      'Featured Products',
      name: 'featured_products',
      desc: '',
      args: [],
    );
  }

  String get what_they_say {
    return Intl.message(
      'What They Say ?',
      name: 'what_they_say',
      desc: '',
      args: [],
    );
  }

  String get favorite_products {
    return Intl.message(
      'Favorite Products',
      name: 'favorite_products',
      desc: '',
      args: [],
    );
  }

  String get options {
    return Intl.message(
      'Options',
      name: 'options',
      desc: '',
      args: [],
    );
  }

  String get select_options_to_add_them_on_the_product {
    return Intl.message(
      'Select options to add them on the product',
      name: 'select_options_to_add_them_on_the_product',
      desc: '',
      args: [],
    );
  }

  String get reviews {
    return Intl.message(
      'Reviews',
      name: 'reviews',
      desc: '',
      args: [],
    );
  }

  String get quantity {
    return Intl.message(
      'Quantity',
      name: 'quantity',
      desc: '',
      args: [],
    );
  }

  String get add_to_cart {
    return Intl.message(
      'Add to Cart',
      name: 'add_to_cart',
      desc: '',
      args: [],
    );
  }

  String get faq {
    return Intl.message(
      'Faq',
      name: 'faq',
      desc: '',
      args: [],
    );
  }

  String get help_supports {
    return Intl.message(
      'Help & Supports',
      name: 'help_supports',
      desc: '',
      args: [],
    );
  }

  String get app_language {
    return Intl.message(
      'App Language',
      name: 'app_language',
      desc: '',
      args: [],
    );
  }

  String get i_forgot_password {
    return Intl.message(
      'I forgot password ?',
      name: 'i_forgot_password',
      desc: '',
      args: [],
    );
  }

  String get i_dont_have_an_account {
    return Intl.message(
      'I don\'t have an account?',
      name: 'i_dont_have_an_account',
      desc: '',
      args: [],
    );
  }

  String get maps_explorer {
    return Intl.message(
      'Maps Explorer',
      name: 'maps_explorer',
      desc: '',
      args: [],
    );
  }

  String get all_product {
    return Intl.message(
      'All Product',
      name: 'all_product',
      desc: '',
      args: [],
    );
  }

  String get longpress_on_the_product_to_add_suplements {
    return Intl.message(
      'Longpress on the product to add suplements',
      name: 'longpress_on_the_product_to_add_suplements',
      desc: '',
      args: [],
    );
  }

  String get notifications {
    return Intl.message(
      'Notifications',
      name: 'notifications',
      desc: '',
      args: [],
    );
  }

  String get confirmation {
    return Intl.message(
      'Confirmation',
      name: 'confirmation',
      desc: '',
      args: [],
    );
  }

  String get your_order_has_been_successfully_submitted {
    return Intl.message(
      'Your order has been successfully submitted!',
      name: 'your_order_has_been_successfully_submitted',
      desc: '',
      args: [],
    );
  }

  String get tax {
    return Intl.message(
      'TAX',
      name: 'tax',
      desc: '',
      args: [],
    );
  }

  String get my_orders {
    return Intl.message(
      'My Orders',
      name: 'my_orders',
      desc: '',
      args: [],
    );
  }

  String get profile {
    return Intl.message(
      'Profile',
      name: 'profile',
      desc: '',
      args: [],
    );
  }

  String get favorites {
    return Intl.message(
      'Favorites',
      name: 'favorites',
      desc: '',
      args: [],
    );
  }

  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  String get payment_options {
    return Intl.message(
      'Payment Options',
      name: 'payment_options',
      desc: '',
      args: [],
    );
  }

  String get cash_on_delivery {
    return Intl.message(
      'Cash on delivery',
      name: 'cash_on_delivery',
      desc: '',
      args: [],
    );
  }

  String get paypal_payment {
    return Intl.message(
      'PayPal Payment',
      name: 'paypal_payment',
      desc: '',
      args: [],
    );
  }

  String get recent_orders {
    return Intl.message(
      'Recent Orders',
      name: 'recent_orders',
      desc: '',
      args: [],
    );
  }

  String get settings {
    return Intl.message(
      'Settings',
      name: 'settings',
      desc: '',
      args: [],
    );
  }

  String get profile_settings {
    return Intl.message(
      'Profile Settings',
      name: 'profile_settings',
      desc: '',
      args: [],
    );
  }

  String get full_name {
    return Intl.message(
      'Full name',
      name: 'full_name',
      desc: '',
      args: [],
    );
  }

  String get email {
    return Intl.message(
      'Email',
      name: 'email',
      desc: '',
      args: [],
    );
  }

  String get phone {
    return Intl.message(
      'Phone',
      name: 'phone',
      desc: '',
      args: [],
    );
  }

  String get address {
    return Intl.message(
      'Address',
      name: 'address',
      desc: '',
      args: [],
    );
  }

  String get payments_settings {
    return Intl.message(
      'Payments Settings',
      name: 'payments_settings',
      desc: '',
      args: [],
    );
  }

  String get default_credit_card {
    return Intl.message(
      'Default Credit Card',
      name: 'default_credit_card',
      desc: '',
      args: [],
    );
  }

  String get app_settings {
    return Intl.message(
      'App Settings',
      name: 'app_settings',
      desc: '',
      args: [],
    );
  }

  String get languages {
    return Intl.message(
      'Languages',
      name: 'languages',
      desc: '',
      args: [],
    );
  }

  String get english {
    return Intl.message(
      'English',
      name: 'english',
      desc: '',
      args: [],
    );
  }

  String get help_support {
    return Intl.message(
      'Help & Support',
      name: 'help_support',
      desc: '',
      args: [],
    );
  }

  String get register {
    return Intl.message(
      'Register',
      name: 'register',
      desc: '',
      args: [],
    );
  }

  String get lets_start_with_register {
    return Intl.message(
      'Let\'s Start with register!',
      name: 'lets_start_with_register',
      desc: '',
      args: [],
    );
  }

  String get should_be_more_than_3_letters {
    return Intl.message(
      'Should be more than 3 letters',
      name: 'should_be_more_than_3_letters',
      desc: '',
      args: [],
    );
  }

  String get john_doe {
    return Intl.message(
      'John Doe',
      name: 'john_doe',
      desc: '',
      args: [],
    );
  }

  String get should_be_a_valid_email {
    return Intl.message(
      'Should be a valid email',
      name: 'should_be_a_valid_email',
      desc: '',
      args: [],
    );
  }

  String get should_be_more_than_6_letters {
    return Intl.message(
      'Should be more than 6 letters',
      name: 'should_be_more_than_6_letters',
      desc: '',
      args: [],
    );
  }

  String get password {
    return Intl.message(
      'Password',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  String get i_have_account_back_to_login {
    return Intl.message(
      'I have account? Back to login',
      name: 'i_have_account_back_to_login',
      desc: '',
      args: [],
    );
  }

  String get multimarkets {
    return Intl.message(
      'Multi-Markets',
      name: 'multimarkets',
      desc: '',
      args: [],
    );
  }

  String get tracking_order {
    return Intl.message(
      'Tracking Order',
      name: 'tracking_order',
      desc: '',
      args: [],
    );
  }

  String get discover__explorer {
    return Intl.message(
      'Discover & Explorer',
      name: 'discover__explorer',
      desc: '',
      args: [],
    );
  }

  String get you_can_discover_markets {
    return Intl.message(
      'You can discover markets & fastproduct arround you and choose you best meal after few minutes we prepare and delivere it for you',
      name: 'you_can_discover_markets',
      desc: '',
      args: [],
    );
  }

  String get reset_cart {
    return Intl.message(
      'Reset Cart?',
      name: 'reset_cart',
      desc: '',
      args: [],
    );
  }

  String get cart {
    return Intl.message(
      'Cart',
      name: 'cart',
      desc: '',
      args: [],
    );
  }

  String get shopping_cart {
    return Intl.message(
      'Shopping Cart',
      name: 'shopping_cart',
      desc: '',
      args: [],
    );
  }

  String get verify_your_quantity_and_click_checkout {
    return Intl.message(
      'Verify your quantity and click checkout',
      name: 'verify_your_quantity_and_click_checkout',
      desc: '',
      args: [],
    );
  }

  String get lets_start_with_login {
    return Intl.message(
      'Let\'s Start with Login!',
      name: 'lets_start_with_login',
      desc: '',
      args: [],
    );
  }

  String get should_be_more_than_3_characters {
    return Intl.message(
      'Should be more than 3 characters',
      name: 'should_be_more_than_3_characters',
      desc: '',
      args: [],
    );
  }

  String get you_must_add_products_of_the_same_markets_choose_one {
    return Intl.message(
      'You must add products of the same markets choose one markets only!',
      name: 'you_must_add_products_of_the_same_markets_choose_one',
      desc: '',
      args: [],
    );
  }

  String get reset_your_cart_and_order_meals_form_this_market {
    return Intl.message(
      'Reset your cart and order meals form this market',
      name: 'reset_your_cart_and_order_meals_form_this_market',
      desc: '',
      args: [],
    );
  }

  String get keep_your_old_meals_of_this_market {
    return Intl.message(
      'Keep your old meals of this market',
      name: 'keep_your_old_meals_of_this_market',
      desc: '',
      args: [],
    );
  }

  String get reset {
    return Intl.message(
      'Reset',
      name: 'reset',
      desc: '',
      args: [],
    );
  }

  String get close {
    return Intl.message(
      'Close',
      name: 'close',
      desc: '',
      args: [],
    );
  }

  String get application_preferences {
    return Intl.message(
      'Application Preferences',
      name: 'application_preferences',
      desc: '',
      args: [],
    );
  }

  String get help__support {
    return Intl.message(
      'Help & Support',
      name: 'help__support',
      desc: '',
      args: [],
    );
  }

  String get light_mode {
    return Intl.message(
      'Light Mode',
      name: 'light_mode',
      desc: '',
      args: [],
    );
  }

  String get dark_mode {
    return Intl.message(
      'Dark Mode',
      name: 'dark_mode',
      desc: '',
      args: [],
    );
  }

  String get log_out {
    return Intl.message(
      'Log out',
      name: 'log_out',
      desc: '',
      args: [],
    );
  }

  String get version {
    return Intl.message(
      'Version',
      name: 'version',
      desc: '',
      args: [],
    );
  }

  String get dont_have_any_item_in_your_cart {
    return Intl.message(
      'D\'ont have any item in your cart',
      name: 'dont_have_any_item_in_your_cart',
      desc: '',
      args: [],
    );
  }

  String get start_exploring {
    return Intl.message(
      'Start Exploring',
      name: 'start_exploring',
      desc: '',
      args: [],
    );
  }

  String get dont_have_any_item_in_the_notification_list {
    return Intl.message(
      'D\'ont have any item in the notification list',
      name: 'dont_have_any_item_in_the_notification_list',
      desc: '',
      args: [],
    );
  }

  String get payment_settings {
    return Intl.message(
      'Payment Settings',
      name: 'payment_settings',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_number {
    return Intl.message(
      'Not a valid number',
      name: 'not_a_valid_number',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_date {
    return Intl.message(
      'Not a valid date',
      name: 'not_a_valid_date',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_cvc {
    return Intl.message(
      'Not a valid CVC',
      name: 'not_a_valid_cvc',
      desc: '',
      args: [],
    );
  }

  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  String get save {
    return Intl.message(
      'Save',
      name: 'save',
      desc: '',
      args: [],
    );
  }

  String get edit {
    return Intl.message(
      'Edit',
      name: 'edit',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_full_name {
    return Intl.message(
      'Not a valid full name',
      name: 'not_a_valid_full_name',
      desc: '',
      args: [],
    );
  }

  String get email_address {
    return Intl.message(
      'Email Address',
      name: 'email_address',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_email {
    return Intl.message(
      'Not a valid email',
      name: 'not_a_valid_email',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_phone {
    return Intl.message(
      'Not a valid phone',
      name: 'not_a_valid_phone',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_address {
    return Intl.message(
      'Not a valid address',
      name: 'not_a_valid_address',
      desc: '',
      args: [],
    );
  }

  String get not_a_valid_biography {
    return Intl.message(
      'Not a valid biography',
      name: 'not_a_valid_biography',
      desc: '',
      args: [],
    );
  }

  String get your_biography {
    return Intl.message(
      'Your biography',
      name: 'your_biography',
      desc: '',
      args: [],
    );
  }

  String get your_address {
    return Intl.message(
      'Your Address',
      name: 'your_address',
      desc: '',
      args: [],
    );
  }

  String get search {
    return Intl.message(
      'Search',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  String get recents_search {
    return Intl.message(
      'Recents Search',
      name: 'recents_search',
      desc: '',
      args: [],
    );
  }

  String get verify_your_internet_connection {
    return Intl.message(
      'Verify your internet connection',
      name: 'verify_your_internet_connection',
      desc: '',
      args: [],
    );
  }

  String get carts_refreshed_successfuly {
    return Intl.message(
      'Carts refreshed successfully',
      name: 'carts_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String the_product_was_removed_from_your_cart(Object productName) {
    return Intl.message(
      'The $productName was removed from your cart',
      name: 'the_product_was_removed_from_your_cart',
      desc: '',
      args: [productName],
    );
  }

  String get category_refreshed_successfuly {
    return Intl.message(
      'Category refreshed successfully',
      name: 'category_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String get notifications_refreshed_successfuly {
    return Intl.message(
      'Notifications refreshed successfully',
      name: 'notifications_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String get order_refreshed_successfuly {
    return Intl.message(
      'Order refreshed successfully',
      name: 'order_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String get orders_refreshed_successfuly {
    return Intl.message(
      'Orders refreshed successfully',
      name: 'orders_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String get market_refreshed_successfuly {
    return Intl.message(
      'Market refreshed successfully',
      name: 'market_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String get profile_settings_updated_successfully {
    return Intl.message(
      'Profile settings updated successfully',
      name: 'profile_settings_updated_successfully',
      desc: '',
      args: [],
    );
  }

  String get payment_settings_updated_successfully {
    return Intl.message(
      'Payment settings updated successfully',
      name: 'payment_settings_updated_successfully',
      desc: '',
      args: [],
    );
  }

  String get tracking_refreshed_successfuly {
    return Intl.message(
      'Tracking refreshed successfully',
      name: 'tracking_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String get welcome {
    return Intl.message(
      'Welcome',
      name: 'welcome',
      desc: '',
      args: [],
    );
  }

  String get wrong_email_or_password {
    return Intl.message(
      'Wrong email or password',
      name: 'wrong_email_or_password',
      desc: '',
      args: [],
    );
  }

  String get addresses_refreshed_successfuly {
    return Intl.message(
      'Addresses refreshed successfuly',
      name: 'addresses_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  String get delivery_addresses {
    return Intl.message(
      'Delivery Addresses',
      name: 'delivery_addresses',
      desc: '',
      args: [],
    );
  }

  String get add {
    return Intl.message(
      'Add',
      name: 'add',
      desc: '',
      args: [],
    );
  }

  String get new_address_added_successfully {
    return Intl.message(
      'New Address added successfully',
      name: 'new_address_added_successfully',
      desc: '',
      args: [],
    );
  }

  String get the_address_updated_successfully {
    return Intl.message(
      'The address updated successfully',
      name: 'the_address_updated_successfully',
      desc: '',
      args: [],
    );
  }

  String get long_press_to_edit_item_swipe_item_to_delete_it {
    return Intl.message(
      'Long press to edit item, swipe item to delete it',
      name: 'long_press_to_edit_item_swipe_item_to_delete_it',
      desc: '',
      args: [],
    );
  }

  String get add_delivery_address {
    return Intl.message(
      'Add Delivery Address',
      name: 'add_delivery_address',
      desc: '',
      args: [],
    );
  }

  String get home_address {
    return Intl.message(
      'Home Address',
      name: 'home_address',
      desc: '',
      args: [],
    );
  }

  String get description {
    return Intl.message(
      'Description',
      name: 'description',
      desc: '',
      args: [],
    );
  }

  String get hint_full_address {
    return Intl.message(
      '12 Street, City 21663, Country',
      name: 'hint_full_address',
      desc: '',
      args: [],
    );
  }

  String get full_address {
    return Intl.message(
      'Full Address',
      name: 'full_address',
      desc: '',
      args: [],
    );
  }

  String get email_to_reset_password {
    return Intl.message(
      'Email to reset password',
      name: 'email_to_reset_password',
      desc: '',
      args: [],
    );
  }

  String get send_password_reset_link {
    return Intl.message(
      'Send link',
      name: 'send_password_reset_link',
      desc: '',
      args: [],
    );
  }

  String get i_remember_my_password_return_to_login {
    return Intl.message(
      'I remember my password return to login',
      name: 'i_remember_my_password_return_to_login',
      desc: '',
      args: [],
    );
  }

  String get your_reset_link_has_been_sent_to_your_email {
    return Intl.message(
      'Your reset link has been sent to your email',
      name: 'your_reset_link_has_been_sent_to_your_email',
      desc: '',
      args: [],
    );
  }

  String get error_verify_email_settings {
    return Intl.message(
      'Error! Verify email settings',
      name: 'error_verify_email_settings',
      desc: '',
      args: [],
    );
  }

  String get guest {
    return Intl.message(
      'Guest',
      name: 'guest',
      desc: '',
      args: [],
    );
  }

  String get you_must_signin_to_access_to_this_section {
    return Intl.message(
      'You must sign-in to access to this section',
      name: 'you_must_signin_to_access_to_this_section',
      desc: '',
      args: [],
    );
  }

  String get tell_us_about_this_market {
    return Intl.message(
      'Tell us about this market',
      name: 'tell_us_about_this_market',
      desc: '',
      args: [],
    );
  }

  String get how_would_you_rate_this_market_ {
    return Intl.message(
      'How would you rate this market ?',
      name: 'how_would_you_rate_this_market_',
      desc: '',
      args: [],
    );
  }

  String get tell_us_about_this_product {
    return Intl.message(
      'Tell us about this product',
      name: 'tell_us_about_this_product',
      desc: '',
      args: [],
    );
  }

  String get the_market_has_been_rated_successfully {
    return Intl.message(
      'The market has been rated successfully',
      name: 'the_market_has_been_rated_successfully',
      desc: '',
      args: [],
    );
  }

  String get the_product_has_been_rated_successfully {
    return Intl.message(
      'The product has been rated successfully',
      name: 'the_product_has_been_rated_successfully',
      desc: '',
      args: [],
    );
  }

  String get reviews_refreshed_successfully {
    return Intl.message(
      'Reviews refreshed successfully!',
      name: 'reviews_refreshed_successfully',
      desc: '',
      args: [],
    );
  }

  String get delivery_fee {
    return Intl.message(
      'Delivery Fee',
      name: 'delivery_fee',
      desc: '',
      args: [],
    );
  }

  String get order_status_changed {
    return Intl.message(
      'Order status changed',
      name: 'order_status_changed',
      desc: '',
      args: [],
    );
  }

  String get new_order_from_client {
    return Intl.message(
      'New order from client',
      name: 'new_order_from_client',
      desc: '',
      args: [],
    );
  }

  String get shopping {
    return Intl.message(
      'Shopping',
      name: 'shopping',
      desc: '',
      args: [],
    );
  }

  String get delivery_or_pickup {
    return Intl.message(
      'Delivery or Pickup',
      name: 'delivery_or_pickup',
      desc: '',
      args: [],
    );
  }

  String get payment_card_updated_successfully {
    return Intl.message(
      'Payment card updated successfully',
      name: 'payment_card_updated_successfully',
      desc: '',
      args: [],
    );
  }

  String get deliverable {
    return Intl.message(
      'Deliverable',
      name: 'deliverable',
      desc: '',
      args: [],
    );
  }

  String get not_deliverable {
    return Intl.message(
      'Not Deliverable',
      name: 'not_deliverable',
      desc: '',
      args: [],
    );
  }

  String get items {
    return Intl.message(
      'Items',
      name: 'items',
      desc: '',
      args: [],
    );
  }

  String get delivery {
    return Intl.message(
      'Delivery',
      name: 'delivery',
      desc: '',
      args: [],
    );
  }

  String get pickup {
    return Intl.message(
      'Pickup',
      name: 'pickup',
      desc: '',
      args: [],
    );
  }

  String get closed {
    return Intl.message(
      'Closed',
      name: 'closed',
      desc: '',
      args: [],
    );
  }

  String get open {
    return Intl.message(
      'Open',
      name: 'open',
      desc: '',
      args: [],
    );
  }

  String get km {
    return Intl.message(
      'Km',
      name: 'km',
      desc: '',
      args: [],
    );
  }

  String get mi {
    return Intl.message(
      'mi',
      name: 'mi',
      desc: '',
      args: [],
    );
  }

  String get delivery_address {
    return Intl.message(
      'Delivery Address',
      name: 'delivery_address',
      desc: '',
      args: [],
    );
  }

  String get current_location {
    return Intl.message(
      'Current location',
      name: 'current_location',
      desc: '',
      args: [],
    );
  }

  String get delivery_address_removed_successfully {
    return Intl.message(
      'Delivery Address removed successfully',
      name: 'delivery_address_removed_successfully',
      desc: '',
      args: [],
    );
  }

  String get add_new_delivery_address {
    return Intl.message(
      'Add new delivery address',
      name: 'add_new_delivery_address',
      desc: '',
      args: [],
    );
  }

  String get markets_near_to_your_current_location {
    return Intl.message(
      'Markets near to your current location',
      name: 'markets_near_to_your_current_location',
      desc: '',
      args: [],
    );
  }

  String get markets_near_to {
    return Intl.message(
      'Markets near to',
      name: 'markets_near_to',
      desc: '',
      args: [],
    );
  }

  String get near_to {
    return Intl.message(
      'Near to',
      name: 'near_to',
      desc: '',
      args: [],
    );
  }

  String get near_to_your_current_location {
    return Intl.message(
      'Near to your current location',
      name: 'near_to_your_current_location',
      desc: '',
      args: [],
    );
  }

  String get pickup_your_product_from_the_market {
    return Intl.message(
      'Pickup your product from the market',
      name: 'pickup_your_product_from_the_market',
      desc: '',
      args: [],
    );
  }

  String get confirm_your_delivery_address {
    return Intl.message(
      'Confirm your delivery address',
      name: 'confirm_your_delivery_address',
      desc: '',
      args: [],
    );
  }

  String get filter {
    return Intl.message(
      'Filter',
      name: 'filter',
      desc: '',
      args: [],
    );
  }

  String get clear {
    return Intl.message(
      'Clear',
      name: 'clear',
      desc: '',
      args: [],
    );
  }

  String get apply_filters {
    return Intl.message(
      'Apply Filters',
      name: 'apply_filters',
      desc: '',
      args: [],
    );
  }

  String get opened_markets {
    return Intl.message(
      'Opened Markets',
      name: 'opened_markets',
      desc: '',
      args: [],
    );
  }

  String get fields {
    return Intl.message(
      'Fields',
      name: 'fields',
      desc: '',
      args: [],
    );
  }

  String get this_product_was_added_to_cart {
    return Intl.message(
      'This product was added to cart',
      name: 'this_product_was_added_to_cart',
      desc: '',
      args: [],
    );
  }

  String get products_result {
    return Intl.message(
      'Products result',
      name: 'products_result',
      desc: '',
      args: [],
    );
  }

  String get products_results {
    return Intl.message(
      'Products Results',
      name: 'products_results',
      desc: '',
      args: [],
    );
  }

  String get markets_results {
    return Intl.message(
      'Markets Results',
      name: 'markets_results',
      desc: '',
      args: [],
    );
  }

  String get all {
    return Intl.message(
      'All',
      name: 'all',
      desc: '',
      args: [],
    );
  }

  String get this_market_is_closed_ {
    return Intl.message(
      'This market is closed !',
      name: 'this_market_is_closed_',
      desc: '',
      args: [],
    );
  }

  String get unknown {
    return Intl.message(
      'Unknown',
      name: 'unknown',
      desc: '',
      args: [],
    );
  }

  String get how_would_you_rate_this_market {
    return Intl.message(
      'How would you rate this market ?',
      name: 'how_would_you_rate_this_market',
      desc: '',
      args: [],
    );
  }

  String get click_on_the_stars_below_to_leave_comments {
    return Intl.message(
      'Click on the stars below to leave comments',
      name: 'click_on_the_stars_below_to_leave_comments',
      desc: '',
      args: [],
    );
  }

  String get click_to_confirm_your_address_and_pay_or_long_press {
    return Intl.message(
      'Click to confirm your address and pay or Long press to edit your address',
      name: 'click_to_confirm_your_address_and_pay_or_long_press',
      desc: '',
      args: [],
    );
  }

  String get visa_card {
    return Intl.message(
      'Visa Card',
      name: 'visa_card',
      desc: '',
      args: [],
    );
  }

  String get mastercard {
    return Intl.message(
      'MasterCard',
      name: 'mastercard',
      desc: '',
      args: [],
    );
  }

  String get paypal {
    return Intl.message(
      'PayPal',
      name: 'paypal',
      desc: '',
      args: [],
    );
  }

  String get pay_on_pickup {
    return Intl.message(
      'Pay on Pickup',
      name: 'pay_on_pickup',
      desc: '',
      args: [],
    );
  }

  String get click_to_pay_with_your_visa_card {
    return Intl.message(
      'Click to pay with your Visa Card',
      name: 'click_to_pay_with_your_visa_card',
      desc: '',
      args: [],
    );
  }

  String get click_to_pay_with_your_mastercard {
    return Intl.message(
      'Click to pay with your MasterCard',
      name: 'click_to_pay_with_your_mastercard',
      desc: '',
      args: [],
    );
  }

  String get click_to_pay_with_your_paypal_account {
    return Intl.message(
      'Click to pay with your PayPal account',
      name: 'click_to_pay_with_your_paypal_account',
      desc: '',
      args: [],
    );
  }

  String get click_to_pay_cash_on_delivery {
    return Intl.message(
      'Click to pay cash on delivery',
      name: 'click_to_pay_cash_on_delivery',
      desc: '',
      args: [],
    );
  }

  String get click_to_pay_on_pickup {
    return Intl.message(
      'Click to pay on pickup',
      name: 'click_to_pay_on_pickup',
      desc: '',
      args: [],
    );
  }

  String get this_email_account_exists {
    return Intl.message(
      'This email account exists',
      name: 'this_email_account_exists',
      desc: '',
      args: [],
    );
  }

  String get this_account_not_exist {
    return Intl.message(
      'This account not exist',
      name: 'this_account_not_exist',
      desc: '',
      args: [],
    );
  }

  String get card_number {
    return Intl.message(
      'CARD NUMBER',
      name: 'card_number',
      desc: '',
      args: [],
    );
  }

  String get expiry_date {
    return Intl.message(
      'EXPIRY DATE',
      name: 'expiry_date',
      desc: '',
      args: [],
    );
  }

  String get cvv {
    return Intl.message(
      'CVV',
      name: 'cvv',
      desc: '',
      args: [],
    );
  }

  String get your_credit_card_not_valid {
    return Intl.message(
      'Your credit card not valid',
      name: 'your_credit_card_not_valid',
      desc: '',
      args: [],
    );
  }

  String get number {
    return Intl.message(
      'Number',
      name: 'number',
      desc: '',
      args: [],
    );
  }

  String get exp_date {
    return Intl.message(
      'Exp Date',
      name: 'exp_date',
      desc: '',
      args: [],
    );
  }

  String get cvc {
    return Intl.message(
      'CVC',
      name: 'cvc',
      desc: '',
      args: [],
    );
  }

  String get completeYourProfileDetailsToContinue {
    return Intl.message(
      'Complete your profile details to continue',
      name: 'completeYourProfileDetailsToContinue',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
      Locale.fromSubtags(languageCode: 'es'),
      Locale.fromSubtags(languageCode: 'fr'),
      Locale.fromSubtags(languageCode: 'in'),
      Locale.fromSubtags(languageCode: 'ko'),
      Locale.fromSubtags(languageCode: 'pt'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    if (locale != null) {
      for (var supportedLocale in supportedLocales) {
        if (supportedLocale.languageCode == locale.languageCode) {
          return true;
        }
      }
    }
    return false;
  }
}